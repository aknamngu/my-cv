﻿namespace _24dh112316
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnBrowse = new Button();
            txtPath = new TextBox();
            btnStart = new Button();
            label1 = new Label();
            IbOutput = new ListBox();
            btnRefresh = new Button();
            btnStop = new Button();
            SuspendLayout();
            // 
            // btnBrowse
            // 
            btnBrowse.BackColor = SystemColors.ActiveCaption;
            btnBrowse.Location = new Point(12, 6);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(112, 34);
            btnBrowse.TabIndex = 0;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = false;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // txtPath
            // 
            txtPath.BackColor = SystemColors.ButtonFace;
            txtPath.Location = new Point(130, 6);
            txtPath.Name = "txtPath";
            txtPath.Size = new Size(540, 31);
            txtPath.TabIndex = 1;
            txtPath.TextChanged += txtPath_TextChanged;
            // 
            // btnStart
            // 
            btnStart.BackColor = SystemColors.ActiveCaption;
            btnStart.Location = new Point(676, 3);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(112, 34);
            btnStart.TabIndex = 2;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = false;
            btnStart.Click += btnStart_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 37);
            label1.Name = "label1";
            label1.Size = new Size(368, 25);
            label1.TabIndex = 3;
            label1.Text = "Các process đã được kích hoạt và đang chạy:";
            // 
            // IbOutput
            // 
            IbOutput.FormattingEnabled = true;
            IbOutput.ItemHeight = 25;
            IbOutput.Location = new Point(12, 88);
            IbOutput.Name = "IbOutput";
            IbOutput.Size = new Size(776, 279);
            IbOutput.TabIndex = 4;
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = SystemColors.ActiveCaption;
            btnRefresh.Location = new Point(12, 389);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(112, 34);
            btnRefresh.TabIndex = 5;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnStop
            // 
            btnStop.BackColor = SystemColors.ActiveCaption;
            btnStop.Location = new Point(676, 389);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(112, 34);
            btnStop.TabIndex = 6;
            btnStop.Text = "Stop";
            btnStop.UseVisualStyleBackColor = false;
            btnStop.Click += btnStop_Click;
            // 
            // Form1
            // 
            AccessibleRole = AccessibleRole.TitleBar;
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(800, 450);
            Controls.Add(btnStop);
            Controls.Add(btnRefresh);
            Controls.Add(IbOutput);
            Controls.Add(label1);
            Controls.Add(btnStart);
            Controls.Add(txtPath);
            Controls.Add(btnBrowse);
            ForeColor = SystemColors.ActiveCaptionText;
            Name = "Form1";
            RightToLeft = RightToLeft.No;
            Text = "Quản lý process";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnBrowse;
        private TextBox txtPath;
        private Button btnStart;
        private Label label1;
        private ListBox IbOutput;
        private Button btnRefresh;
        private Button btnStop;
    }
}
